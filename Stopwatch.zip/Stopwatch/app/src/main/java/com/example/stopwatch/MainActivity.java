package com.example.stopwatch;

import android.os.Handler;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Button;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    Button start, stop, lap, reset;
    TextView stopwatch;
    ListView detail_lap;
    int detik, menit, millisecond;
    long millisecondTime, startTime, timeBuffering, updateTime = 0L;
    Handler handler;
    String[] ListElements = new String[]{};
    List<String> ListElementsArrayList;
    ArrayAdapter<String> adapter;
    Runnable runnable = new Runnable() {
        @Override
        public void run() {
            detik = (int) (updateTime / 1000);
            detik = detik % 60;
            menit = detik / 60;
            millisecond = (int) (updateTime % 1000);
            millisecondTime = SystemClock.uptimeMillis() - startTime;
            updateTime = timeBuffering + millisecondTime;

            stopwatch.setText(menit + ":" + detik + ":" + millisecond);

            handler.postDelayed(this,0);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        start = findViewById(R.id.start);
        stop = findViewById(R.id.stop);
        lap = findViewById(R.id.lap);
        reset = findViewById(R.id.reset);
        stopwatch = findViewById(R.id.stopwatch);
        detail_lap = findViewById(R.id.detail_lap);

        handler = new Handler();

        ListElementsArrayList = new ArrayList<String>(Arrays.asList(ListElements));

        adapter = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1, ListElementsArrayList);

        detail_lap.setAdapter(adapter);

        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startTime = SystemClock.uptimeMillis();
                handler.postDelayed(runnable,0);

                reset.setEnabled(false);
            }
        });

        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                timeBuffering += millisecondTime;
                handler.removeCallbacks(runnable);

                reset.setEnabled(true);
            }
        });

        lap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ListElementsArrayList.add(stopwatch.getText().toString());

                adapter.notifyDataSetChanged();
            }
        });

        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                detik = 0;
                menit = 0;
                millisecond = 0;
                millisecondTime = 0L;
                startTime = 0L;
                timeBuffering = 0L;
                updateTime = 0L;

                stopwatch.setText("00:00:00");

                ListElementsArrayList.clear();

                adapter.notifyDataSetChanged();
            }
        });
    }
}
